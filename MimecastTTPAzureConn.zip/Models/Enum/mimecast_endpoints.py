class MimecastEndpoints:

    get_ttp_url_logs = "/api/ttp/url/get-logs"
    get_ttp_impersonation_logs = "/api/ttp/impersonation/get-logs"
    get_ttp_attachment_logs = "/api/ttp/attachment/get-logs"
    refresh_access_key = "/api/login/login"
